// LibraryApp.java
import java.util.Scanner;

public class LibraryApp {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        //This is sample data
        // https://study.com/academy/lesson/infinite-while-loops-in-java.html#:~:text=An%20infinite%20while%20loop%20in,This%20means%20it%20will%20fail.
        // student.com
        
        library.addBook(new Book("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565"));
        library.addBook(new Book("To Kill a Mockingbird", "Harper Lee", "9780060935467"));
        library.addUser(new User(1, "Alice"));
        library.addUser(new User(2, "Bob"));

        while (true) {
            printMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    library.listBooks();
                    break;
                case 2:
                    addNewBook(scanner, library);
                    break;
                case 3:
                    searchBook(scanner, library);
                    break;
                case 4:
                    borrowBook(scanner, library);
                    break;
                case 5:
                    returnBook(scanner, library);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }

            System.out.print("Enter (1) to launch menu or any other key to exit: ");
            String input = scanner.nextLine();
            if (!input.equals("1")) {
                System.out.println("Exiting...");
                break;
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("=============================================================");
        System.out.println("                      LIBRARY MANAGEMENT SYSTEM              ");
        System.out.println("=============================================================");
        System.out.println("1. LIST ALL BOOKS");
        System.out.println("2. ADD A NEW BOOK");
        System.out.println("3. SEARCH FOR A BOOK BY TITLE");
        System.out.println("4. BORROW A BOOK");
        System.out.println("5. RETURN A BOOK");
        System.out.println("6. EXIT");
        System.out.println("-------------------------------------------------------------");
        System.out.print("Enter your choice (1-6): ");
    }

    private static void addNewBook(Scanner scanner, Library library) {
        System.out.println("=============================================================");
        System.out.println("                       ADD A NEW BOOK                        ");
        System.out.println("=============================================================");
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter ISBN: ");
        String isbn = scanner.nextLine();
        library.addBook(new Book(title, author, isbn));
    }

    private static void searchBook(Scanner scanner, Library library) {
        System.out.println("=============================================================");
        System.out.println("                      SEARCH FOR A BOOK                      ");
        System.out.println("=============================================================");
        System.out.print("Enter book title to search: ");
        String searchTitle = scanner.nextLine();
        Book foundBook = library.searchBookByTitle(searchTitle);
        if (foundBook != null) {
            System.out.println(foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }

    private static void borrowBook(Scanner scanner, Library library) {
        System.out.println("=============================================================");
        System.out.println("                         BORROW A BOOK                       ");
        System.out.println("=============================================================");
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter book title to borrow: ");
        String borrowTitle = scanner.nextLine();
        User user = library.users.get(userId - 1);  // Simplified user retrieval
        Book borrowBook = library.searchBookByTitle(borrowTitle);
        library.borrowBook(user, borrowBook);
    }

    private static void returnBook(Scanner scanner, Library library) {
        System.out.println("=============================================================");
        System.out.println("                        RETURN A BOOK                        ");
        System.out.println("=============================================================");
        System.out.print("Enter user ID: ");
        int returnUserId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        User returnUser = library.users.get(returnUserId - 1);  // Simplified user retrieval
        library.returnBook(returnUser);
    }
}
