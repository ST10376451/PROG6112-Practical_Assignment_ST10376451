// LibraryTest.java
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LibraryTest {
    private Library library;
    private Book book1, book2;
    private User user1, user2;

    @BeforeEach
    public void setUp() {
        library = new Library();
        book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "9780743273565");
        book2 = new Book("To Kill a Mockingbird", "Harper Lee", "9780060935467");
        user1 = new User(1, "Alice");
        user2 = new User(2, "Bob");
        
        library.addBook(book1);
        library.addBook(book2);
        library.addUser(user1);
        library.addUser(user2);
    }

    @Test
    public void testAddBook() {
        Book newBook = new Book("1984", "George Orwell", "9780451524935");
        library.addBook(newBook);
        assertTrue(library.books.contains(newBook), "The book should be added to the library.");
    }

    @Test
    public void testSearchBookByTitle() {
        Book foundBook = library.searchBookByTitle("The Great Gatsby");
        assertNotNull(foundBook, "The book should be found.");
        assertEquals("The Great Gatsby", foundBook.getTitle(), "The title of the found book should match the search term.");
    }

    @Test
    public void testSearchBookByTitle_NotFound() {
        Book foundBook = library.searchBookByTitle("Non-Existent Book");
        assertNull(foundBook, "The book should not be found.");
    }

    @Test
    public void testBorrowBook() {
        library.borrowBook(user1, book1);
        assertFalse(book1.isAvailable(), "The book should not be available after being borrowed.");
        assertEquals(book1, user1.getBorrowedBook(), "The borrowed book should be recorded in the user's borrowed book.");
    }

    @Test
    public void testBorrowBook_AlreadyBorrowed() {
        library.borrowBook(user1, book1);
        library.borrowBook(user2, book1);
        assertFalse(book1.isAvailable(), "The book should not be available after being borrowed.");
        assertNull(user2.getBorrowedBook(), "The second user should not be able to borrow an already borrowed book.");
    }

    @Test
    public void testReturnBook() {
        library.borrowBook(user1, book1);
        library.returnBook(user1);
        assertTrue(book1.isAvailable(), "The book should be available after being returned.");
        assertNull(user1.getBorrowedBook(), "The user's borrowed book should be null after returning the book.");
    }

    @Test
    public void testReturnBook_NoBorrowedBook() {
        library.returnBook(user1);
        assertNull(user1.getBorrowedBook(), "The user's borrowed book should remain null if no book was borrowed.");
    }
}
