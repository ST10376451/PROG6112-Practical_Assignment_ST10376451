// User.java
// Represents a library user with ID, name, and a borrowed book.

public class User {
    private int userId;
    private String name;
    private Book borrowedBook;

    public User(int userId, String name) {
        this.userId = userId;
        this.name = name;
        this.borrowedBook = null;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public Book getBorrowedBook() {
        return borrowedBook;
    }

    public void borrowBook(Book book) {
        this.borrowedBook = book;
    }

    public void returnBook() {
        this.borrowedBook = null;
    }

    @Override
    public String toString() {
        return "User ID: " + userId + ", Name: " + name + ", Borrowed Book: " + (borrowedBook != null ? borrowedBook.getTitle() : "None");
    }
}
