// Library.java
import java.util.ArrayList;
import java.util.List;

public class Library {
     List<Book> books;
    List<User> users;

    public Library() {
        books = new ArrayList<>();
        users = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book);
    }

    public void addUser(User user) {
        users.add(user);
        System.out.println("User added: " + user);
    }

    public void listBooks() {
        System.out.println("Listing all books:");
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public Book searchBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

// Allows a user to borrow a book if available and updates records.
// https://www.w3schools.com/java/java_conditions.asp
// w3schools

    public void borrowBook(User user, Book book) {
        if (book != null && book.isAvailable()) {
            book.setAvailable(false);
            user.borrowBook(book);
            System.out.println(user.getName() + " borrowed " + book.getTitle());
        } else {
            System.out.println("Book is not available or does not exist.");
        }
    }

    public void returnBook(User user) {
        Book book = user.getBorrowedBook();
        if (book != null) {
            book.setAvailable(true);
            user.returnBook();
            System.out.println(user.getName() + " returned " + book.getTitle());
        } else {
            System.out.println("No book to return.");
        }
    }
}
