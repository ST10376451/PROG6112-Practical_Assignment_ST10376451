import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentTest {

    @BeforeEach
    void setUp() {
        // Clear existing students before each test to avoid conflicts
        Student.getStudents().clear();
        // Add some initial students for testing
        Student.addStudent(new Student("10111", "J.Bloggs", 19, "123 Main St", "jbloggs@ymail.com", "disd"));
        Student.addStudent(new Student("10112", "J.Doe", 21, "456 Elm St", "jdoe@ymail.com", "disd"));
        Student.addStudent(new Student("10113", "P.Parker", 20, "789 Oak St", "spidey@ymail.com", "disn"));
    }

    @Test
    void testAddStudent() {
        Student.addStudent(new Student("10114", "B.Wayne", 22, "Wayne Manor", "batman@dc.com", "buis"));
        assertEquals(4, Student.getStudents().size());
        assertNotNull(Student.searchStudent("10114"));
    }

    @Test
    void testSearchStudent() {
        Student student = Student.searchStudent("10111");
        assertNotNull(student);
        assertEquals("J.Bloggs", student.getName());
    }

    @Test
    void testSearchStudent_NotFound() {
        Student student = Student.searchStudent("99999");
        assertNull(student);
    }

    @Test
    void testDeleteStudent() {
        boolean isDeleted = Student.deleteStudent("10112");
        assertTrue(isDeleted);
        assertNull(Student.searchStudent("10112"));
    }

    @Test
    void testDeleteStudent_NotFound() {
        boolean isDeleted = Student.deleteStudent("99999");
        assertFalse(isDeleted);
    }

    @Test
    void testPrintAllStudents() {
        Student.printAllStudents();
        assertEquals(3, Student.getStudents().size());
    }
}
