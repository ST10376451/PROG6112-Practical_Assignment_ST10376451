import java.util.Scanner;

public class StudentManagementApp {
    private static Scanner scanner = new Scanner(System.in);

    // The main method of the application that implements a console-based menu system. It continuously displays a menu and processes user input based on the chosen option.
    // https://www.w3schools.com/java/java_while_loop.asp
    // w3schools
    public static void main(String[] args) {
        while (true) {
            displayMenu();
            String choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    captureNewStudent();
                    break;
                case "2":
                    searchStudent();
                    break;
                case "3":
                    deleteStudent();
                    break;
                case "4":
                    printStudentReport();
                    break;
                case "5":
                    System.out.println("Exiting application.");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void displayMenu() {
        System.out.println("*******************************");
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("*******************************");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student.");
        System.out.println("(2) Search for a student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit application.");
        System.out.print("Enter your choice: ");
    }

    private static void captureNewStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.print("Enter the student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();
        int age = 0;
        while (true) {
            System.out.print("Enter the student age (16 or older): ");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("Age must be 16 or older. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for age.");
            }
        }
        System.out.print("Enter the student address: ");
        String address = scanner.nextLine();
        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();
        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();
        
        // Create and add new student
        Student newStudent = new Student(id, name, age, address, email, course);
        Student.addStudent(newStudent);
    }

    private static void searchStudent() {
        System.out.print("Enter student ID to search: ");
        String id = scanner.nextLine();
        Student student = Student.searchStudent(id);
        if (student != null) {
            System.out.println("Student Found: " + student);
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        String id = scanner.nextLine();
        Student.deleteStudent(id);
    }

    private static void printStudentReport() {
        Student.printAllStudents();
    }
}