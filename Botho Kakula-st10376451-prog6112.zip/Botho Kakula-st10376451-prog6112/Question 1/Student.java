import java.util.ArrayList;

class Student {
    private String id;
    private String name;
    private int age;
    private String address;
    private String email;
    private String course;

    // Static list to store students, managing them inside the Student class
    private static ArrayList<Student> students = new ArrayList<>();
    
    public Student(String id, String name, int age, String address, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.address = address;
        this.email = email;
        this.course = course;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getAddress() { return address; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }

    @Override
    public String toString() {
        return "ID: " + id + ", Name: " + name + ", Age: " + age + ", Address: " + address + ", Email: " + email + ", Course: " + course;
    }

    public static ArrayList<Student> getStudents() {
        return students;
    }

    // This is a static method used to add a new student
    // https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html
    // Oracle
    public static void addStudent(Student student) {
        students.add(student);
        System.out.println("Student added successfully!");
    }

    // Static method to search for a student by ID
    public static Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }

    // Static method to delete a student by ID
    public static boolean deleteStudent(String id) {
        Student student = searchStudent(id);
        if (student != null) {
            students.remove(student);
            System.out.println("Student deleted successfully.");
            return true;
        }
        System.out.println("Student not found.");
        return false;
    }

    //  This is a static method to print all students' details in a formatted manner
    // https://www.geeksforgeeks.org/system-out-println-in-java/
    // geek for geeks
    public static void printAllStudents() {
        if (students.isEmpty()) {
            System.out.println("No students available.");
            return;
        }

        System.out.println("Student Report:");
        System.out.println("===========================================");
        int count = 1;
        for (Student student : students) {
            System.out.println("STUDENT " + count++);
            System.out.println("-------------------------------------------");
            System.out.println("STUDENT ID: " + student.getId());
            System.out.println("STUDENT NAME: " + student.getName());
            System.out.println("STUDENT AGE: " + student.getAge());
            System.out.println("STUDENT EMAIL: " + student.getEmail());
            System.out.println("STUDENT COURSE: " + student.getCourse());
            System.out.println("-------------------------------------------");
        }
        System.out.println("Enter (1) to launch menu or any other key to exit");
    }
}
